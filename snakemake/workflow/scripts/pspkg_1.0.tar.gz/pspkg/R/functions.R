# functions for pspkg
if (!require("BiocManager", quietly = TRUE))
    install.packages("BiocManager")

if (!require("GenomicRanges", quietly = TRUE))
    BiocManager::install("GenomicRanges")

library("GenomicRanges")



# functions
# function to read in file and go through each bin, 
# calculate avg contact frequency across all pairs for each bin, 
# then put each bin's average into a row in a new output data frame
# df is a df of contact frequency pairs, cf_col refers to which column in the df contains the contact frequencies
read_and_avg_df <- function(df, cf_col) {
    data <- read.table(file = df, header = FALSE, sep = "\t")
    avg_data <- sapply(unique(data[1])[[1]], function (x) { log2(mean(as.numeric(data[data[1]==x,][[cf_col]]), na.rm=TRUE)) } )
    with_bin_names <- data.frame(bin=seq(0,length(avg_data)-1),pairing_score=avg_data)
    return(with_bin_names)
}

# this combines the above with some bins containing chromosomal coordinates
combine_bins_and_df <- function(df, bins) {
   bin <- read.table(file = bins, header = FALSE, sep = "\t")
   names(bin) <- c("chrom", "start", "end", "bin")
   # nas need to be padded if there are more bins than pairing scores
#   max_row <- max(c(nrow(bin), nrow(df))) # evaluate how many bins there are vs ps
   repr<-rep(NA, nrow(bin) - nrow(df)) # get nas for the shortfall
#   nas<-data.frame(repr, repr, repr) # 
   nas <-data.frame(rep(data.frame(repr), ncol(df))) # this does the nas based on column lengths
    # set names equal
   names(nas) <- names(df)
   # in this case the last bin column will be redundant so its removed
   newdf <- data.frame(bin[-4], rbind(df, nas))

   return(newdf)
}

# now a features fasta file containing transposon coordinates is parsed. these yeast just have LTR so this is the string for grep.
#reverse complement
lookup_tes <- function(df, features, string, te_vector) {
    feats<-readLines(features)
    tes <- feats[grepl(string, feats)]
    # reverse complement needs to be removed now or genomic ranges will complain about ends being smalelr than starts
#    tes <-tes_with_rev_complement[!grepl("reverse_complement", tes_with_rev_complement)]
    # reformat into bed format with the original string as a column for reference.
    # first get coords string and put in tab deliminations
    coords_string <- lapply(tes, function(x) { gsub("\ Chr\ ", "chr_", gsub("-", "\t", gsub("\ from\ ", "\t", unlist(strsplit(x, ","))[2])))})
    # now turn this into a data frame and add the original string to a new column
    coords_bed <- read.table(text=unlist(coords_string), sep="\t", col.names=c("chrom", "start", "end"))
    tes_bed <- data.frame(coords_bed, te_family=tes, fasta_string=tes)
    # build out te_family column with vector of tes
     for (x in te_vector) { tes_bed[[4]] <- gsub(paste0(".*",x,".*"), x, tes_bed[[4]])}
    # fix roman numeral columns from fasta file and turn them into numbers
    tes_bed[[1]]<-as.numeric(as.roman(sub(".*_", "", tes_bed[[1]])))
    # flip reverse complement strands so genomic ranges does not have an error about this issue of ends beign smaller than starts
    te_bed<-transform(tes_bed, end = pmax(end, start), start = pmin(end, start))
    return(te_bed)
}

# function for lookup tes to deal with mm9_rmsk_TE.gtf.locInd.locations and convert to bed
lookup_tes_mm9 <- function(locations) {
#    locs <- read.delim(locations, nrows=10)
    locs <- read.delim(locations)
#    locs2 <- gsub(":", "\t", locs)
#    locs_df <- data.frame(locs)
    # for reformatting the coordinates
    pattern <- "(.*?):([[:digit:]]+)-([[:digit:]]+)"
    proto <- data.frame(chrom=character(), start=integer(), end=integer())
    coords <- strcapture(pattern, gsub('.{2}$', '', locs[[2]]), proto)
    # get strand
    strand <- substring(locs[[2]], nchar(locs[[2]]))
    # combine them all
    all <- cbind(coords, strand=strand, te_family=locs[[1]])
    all[[1]]<-gsub("^.{0,3}", "", all[[1]]) # fixing chr1 to 1 etc.
    # in this section things like_dup123 are removed from te family names
    all$te_fam <- gsub("_dup.+$", "", all$te_family)
    #all$te_dup_number <- gsub("^.+_dup", "", all$te_family)
    all$te_family <- NULL	# get rid of old te family string
    all$te_family <- all$te_fam	# replace it with the new one
    all$te_fam <- NULL	# get rid of the unneeded column
    return(all)
}

# this function will split the pairing data up into either mat or pat bed depending on what is asked for 
# one is DBVPG6044 the other is Y12
chrsplit <- function(bed, chr) {
    newbed <- bed[grep(paste0(chr, ".*"), bed[[1]]),]
    newbed[[1]] <- as.numeric(gsub(paste0(chr, "_"), "", newbed[[1]]))
    return(newbed)
}


# this function takes a pairing score bed file, and another bed file like the te file or any other, and adds pairing score information to it in a new column based on the overlap in pairing score bins for a given feature in the bed.
# bed1 is the one that the output will keep the coords for output
# bed2 is what its being compared with
# this only works with bed1 being tes for now... so its not per bin tes its a per te pairing score ocmputed 
overlap_beds <- function(bed1,bed2) {
    ranges<-merge(bed1,bed2,by="chrom",suffixes=c("bed1","bed2"))
    # start of bed 2 is less than or equal to the start of bed 1 (e.g. 1238 is less than or equal to 1500 for 500kb bed)
    # 
    overlaps<-ranges[with(ranges, startbed2 <= startbed1 & endbed2 >= endbed1),]
    return(overlaps)
}


# lets plot up the tes and their pairing scores at least along with median region
# first get the table to be boxplotted
plotting_tes_pairing <- function(te_bed, pairing_bins_bed) {
    # first i will extract the columns i care about the te and the pairing score
    tes <- te_bed[c("te_family", "pairing_score")]
    # now i will append all bins to this group. te_family column is basically just a feature column now since it also contains all bins pairing scores
    tes_and_total <- rbind(tes, data.frame(te_family="genome", pairing_score=pairing_bins_bed["pairing_score"]))
    return(tes_and_total)
}

# function for computing some means and medians per te
# tes bed is a bed of tes to use from lookup tes
# pairing bed is the parental pairing genome to use from chrsplit output e.g. df_Y12 or df_DBVPG6044

# this function to be used as a scaffold for a plotting function like what was done in the dmel pnm data
# this pnm data file was ran with "everything in one bed" so to speak, while the other data for yeast and mouse are kept separate until here between
# te posiitons and the pairing score
# this was because te positions were taken from the reference genome for these latter files and for the pnm tes were in fact called from sequencing data,
# using the reference adn te finder to identifiy these insertions

# this function remains a good setup using granges to abrogate these files.
# similarly a total genome bar will be created for the eventual plot.
compute_means_medians <- function(tes_bed, pairing_bed) {
    #test<-plotting_tes_pairing(overlap_beds(tes_bed, df_Y12), df_Y12)
    #bed <- plotting_tes_pairing(overlap_beds(tes_bed, pairing_bed), pairing_bed)
    # using granges tooling seems to work better for large beds than R overlap methods
    granges <- mergeByOverlaps(makeGRangesFromDataFrame(tes_bed, keep.extra.columns=TRUE), makeGRangesFromDataFrame(pairing_bed, keep.extra.columns=TRUE))
    bed <- as.data.frame(cbind(te_family=granges$te_family, pairing_score=granges$pairing_score))
    
    medians <- sapply(sort(unlist(unique(bed[1]), use.names = FALSE)), function (x) { median(as.numeric(unlist(bed[bed["te_family"]==x,]["pairing_score"])), na.rm=TRUE)})
    means <- sapply(sort(unlist(unique(bed[1]), use.names = FALSE)), function (x) { mean(as.numeric(unlist(bed[bed["te_family"]==x,]["pairing_score"])), na.rm=TRUE)})
    # calculate genomic mean and median for all bins
    gen_median <- median(as.numeric(pairing_bed$pairing_score), na.rm=TRUE)
    gen_mean <- mean(as.numeric(pairing_bed$pairing_score), na.rm=TRUE)

    # add them to the means and medians object. genome= for all bins which we have a pairing score whether te in or not
    medians <- c(medians, genome=gen_median)
    means <- c(means, genome=gen_mean)
    results <- rbind(median=medians, mean=means)
    return(results)
}

# this funciton gets the te family unique value from tes bed as a list
te_tf_gette_fam <- function(tes_bed){
    list_of_unique_tes <- sort(unique(makeGRangesFromDataFrame(tes_bed, keep.extra.columns=TRUE)$te_family))
    return(list_of_unique_tes)
}
# the purpose of the function below is, for a given te_family, get overlapping ranges with the pairing scores
te_tf <- function(tes_bed, pairing_bed, te_family){
    tes <- makeGRangesFromDataFrame(tes_bed, keep.extra.columns=TRUE)
    pairranges <- makeGRangesFromDataFrame(pairing_bed, keep.extra.columns=TRUE)
    # now that granges objects are loaded subset te data for a given te family
    te_family_tes <- makeGRangesFromDataFrame(tes_bed, keep.extra.columns=TRUE)[grepl(te_family, makeGRangesFromDataFrame(tes_bed, keep.extra.columns=TRUE)$te_family)]
    subsets<- subsetByOverlaps(makeGRangesFromDataFrame(pairranges, keep.extra.columns=TRUE), te_family_tes)
    return(subsets)
}

tetester_new_for_tetf <- function(te_bed_subset, pairing_bed,test) {
    # test is either wilcox or t
#    i1 <-  colSums(table(df)!=0)>=3
#    df2<-na.omit(df[df[[colb]] %in% names(i1)[i1],])
    if ( test == "t" ) {
#        testr <-pairwise.t.test(df2[[cola]], df2[[colb]], p.adjust.method=padj)
        testr <- t.test(te_bed_subset$pairing_score, pairing_bed$pairing_score)
    } else if ( test == "wilcox" ) {
        testr <- wilcox.test(te_bed_subset$pairing_score, pairing_bed$pairing_score)
 #       testr <-pairwise.wilcox.test(df2[[cola]], df2[[colb]], p.adjust.method=padj)
    } else {
        stop("Please specify a test.")
    }
    #testr$p.value["No TE",][testr$p.value["No TE",]<=pvc]
    return(testr$p.value)
}

# function to iterate through and run these wilcox tests on multiple tes
# test is test performed e.g. wilcox
# pvc is the p value cutoff after correction
multipletests <- function(tes_bed, pairing_bed, test, pvc){
    # first get a list of tes from tes_Bed
    te_list<-te_tf_gette_fam(tes_bed)
    pvals<- sapply(te_list, function(te_family){ 
#           
        tetf<-te_tf(tes_bed_du, df_du_mat, te_family) 
        #print(te_family)
        # granges objects dont have rows but length
        if ( length(tetf) > 2 ) {        
            tetester_new_for_tetf(tetf, pairing_bed, test)
        }
    })
    # pvals may have null values after this so this line fixes that:
    pvals <- pvals[lengths(pvals) != 0]
    pvals <- p.adjust(pvals, method = "bonferroni")
    sigp <- which(pvals <= pvc) # returns significant values less than or equal to cutoff
    return(pvals[sigp])
}

# functions for setting up a binomial test below:
# step 1: table of vectors from means and median function output
# dat input is something like du_mat_means_medians
# there must be a column labelled genome for genomic values (set via flag)
# output is a table of these means/medians with a 1 or 0 (1 if p.s. greater than genome value, 0 if not)
# number of columns in the output corresponds to number of TEs, genome column that was in input is therefore dropped

get_means_medians_booleans <- function(dat, genome="genome"){
    # subset without genomic values:  t(dat)[!(rownames(t(dat)) == "genome"), "mean"]
    # subset of only genomic values: t(dat)[(rownames(t(dat)) == "genome"),]     
    # note that this returns a table of true and false but the *1 at the end there converts it to numeric 0=false 1=true
    bools<-sapply(stat, function (x) { (t(dat)[!(rownames(t(dat)) == genome), x] > t(dat)[(rownames(t(dat)) == genome), x])*1 } )
    return(bools)
}

# now we run the binomial test on each column. same dat input as above as the get_means_medians_booleans function is used internal to this one
run_binom_test_on_booleans <- function(dat, stat = c("mean", "median"), genome = "genome") {
    # rounding step for dat
    dat <- round(dat,2)
    bools <- sapply(stat, function (x) { (t(dat)[!(rownames(t(dat)) == genome), x] > t(dat)[(rownames(t(dat)) == genome), x])*1 } )
    test <- sapply(stat, function (x) {
                binom.test(x = nrow(bools) - sum(bools[,x]),
                           n = nrow(bools),
                           p = 0.5,
                           conf.level = 0.95)
                    }
                )
    return(test)
}



# tests columns against another and bonferroni corrects p value
# list of values is used in this case not necessarily a df
tetester <- function(df,cola,colb,pvc,test,padj) {
    # cola is usually "pairing_score" and colb is usually "dna_te_family" depending on what is ran
    # pvc is p value cutoff
    # first get observations with greater than 3 values
    # bf boolean is true or false to do a bonferroni correction based on size of df
    # test is either wilcox or t
    # padj can be "bonferroni"
    # example: ttester(tes, pairing_score, dna_te_family, 0.05, t, bonferroni)
    i1 <-  colSums(table(df)!=0)>=3
    df2<-na.omit(df[df[[colb]] %in% names(i1)[i1],])
    if ( test == "t" ) {
        testr <-pairwise.t.test(df2[[cola]], df2[[colb]], p.adjust.method=padj)
    } else if ( test == "wilcox" ) {
        testr <-pairwise.wilcox.test(df2[[cola]], df2[[colb]], p.adjust.method=padj)
    } else {
        stop("Please specify a test.")
    }
    #testr$p.value["No TE",][testr$p.value["No TE",]<=pvc]
    return(na.exclude(testr$p.value["No TE",])[na.exclude(testr$p.value["No TE",])<=pvc])
}

plot_te_family_ps <- function(te_bed){
    testing<-tetester(te_bed, "pairing_score", "dna_te_family", 0.05, "t", "bonferroni")
    # subset based on being in this p value cutoff of 0.05 for plotting
    plote<-as.data.frame(te_bed[te_bed$dna_te_family %in% c(names(testing), "No TE"),])
    # section to count groups
    levs<-levels(factor(plote$dna_te_family))
    # first before messing with names i will get my p values using names
    pvals<-as.vector(signif(testing[order(match(names(testing),levs))],3))
    # then replace levs
    levs2<-paste0(levs, " (n=", as.vector(table(plote$dna_te_family)), ")")
    plote$dna_te_family <- factor(plote$dna_te_family, labels = levs2)
    #bymedian <- with(plote, reorder("dna_te_family", "pairing_score", median, na.rm=TRUE))
    bymedian <- with(plote, reorder(dna_te_family, pairing_score, median, na.rm=T))
    # bigger plot for horizontal figs
#    pdf(file = paste0(figpath, "/", figname, "horizontal_", sprintf("%03d", i), ".pdf"),
#        width = 11, height = 8)

#    par(las=2) # perpendicular axis labels with las=2
#    par(mar=c(10,8,4,1))
    return(bymedian)
}

non_overlap_beds <- function(bed1,bed2) {
    ranges<-merge(bed1,bed2,by="chrom",suffixes=c("bed1","bed2"))
    overlaps<-ranges[with(ranges, startbed2 > startbed1 & startbed2 > endbed1),]
    return(overlaps)
}

# function based on pats stuff
te_counter <- function(tes_bed, df_gt) {
    tes_granges<-makeGRangesFromDataFrame(tes_bed,  keep.extra.columns=TRUE)
    gt_granges<-makeGRangesFromDataFrame(df_gt,  keep.extra.columns=TRUE)
#    overlaps.dtbl <- as.data.table(mergeByOverlaps(tes_granges, gt_granges))
    overlaps.frame <- mergeByOverlaps(tes_granges, gt_granges)
#    te_counts <- as.data.frame.matrix(with(overlaps.frame, table(gt_granges, te_family)))
    te_counts <- table(overlaps.frame$gt_granges, overlaps.frame$te_family)
#    te_counts <- sapply(overlaps.frame$gt_ranges, function(x) { table(x, overlaps.dtbl$te_family) })
    total_te_counts <- rowSums(te_counts)
    te_counts <- cbind(te_counts, total_te_counts)
    return(te_counts)
}


#### newer functions below here
unsplit_te <- function(ps,te) {
    # this function will unsplit rows with multiple tes and put them on a new row to preserve score info per te (if multiple tes are per bin e.g.)
    # see: https://stackoverflow.com/a/15347463
    # ps is a data frame column defining pairing score info 
    # te defines te FAMILY eg data$dna_te_family
    # e.g. unsplit_te(data$pairing_score, data$dna_te_family)
    s<-strsplit(te, split = ",")
    df<-data.frame(V1 = rep(ps, sapply(s, length)), V2 = unlist(s))
    # convert ps to numeric values
    df2<-data.frame(as.numeric(df$V1), gsub("\\.", "No TE", df$V2))
    return(df2)
}




plottes <-function(df,cola,colb,pvc,test,padj){
    # col a is e.g. pairing score # col b is e.g dna_te_family
    tes<-unsplit_te(data$pairing_score, data$dna_te_family)
    names(tes)<-c("pairing_score", "dna_te_family")

    testing<-tetester(tes, "pairing_score", "dna_te_family", 0.05, "t", "bonferroni")
    # subset based on being in this p value cutoff of 0.05 for plotting
    plote<-as.data.frame(tes[tes$dna_te_family %in% c(names(testing), "No TE"),])
    # section to count groups
    levs<-levels(factor(plote$dna_te_family))
    # first before messing with names i will get my p values using names
    pvals<-as.vector(signif(testing[order(match(names(testing),levs))],3))
    # then replace levs
    levs2<-paste0(levs, " (n=", as.vector(table(plote$dna_te_family)), ")")
    plote$dna_te_family <- factor(plote$dna_te_family, labels = levs2)
    #bymedian <- with(plote, reorder("dna_te_family", "pairing_score", median, na.rm=TRUE))
    bymedian <- with(plote, reorder(dna_te_family, pairing_score, median, na.rm=T))
    # bigger plot for horizontal figs
    pdf(file = paste0(figpath, "/", figname, "horizontal_", sprintf("%03d", i), ".pdf"),
        width = 11, height = 8)

    #par(las=1) # horizontal axis labels with las=1
    par(las=2) # perpendicular axis labels with las=2
    par(mar=c(10,8,4,1))
    b<-boxplot(pairing_score ~ bymedian, plote, main = "Pairing Score per Transposable Element (TE) Family in PnM DNA", ylab = "Pairing Score per 4kb window", xlab = "")
    # add ns to names
    #pvals<-as.vector(signif(testing[order(match(names(testing),b$names))],3))
    #b$names<-paste0(b$names, " (n=", b$n, ")")

    #text(1:length(b$n), b$stats[5,]+1, paste("n=", b$n), srt=90)
    #text(1:(length(b$n)-1), b$stats[5,]+1, paste("p=", pvals), srt=90, cex=0.8)
    # p vals is one less than length of all the bars plus note since note has no p needs to be excluded like below with the blank in c().
    # note last p= still comes through here and needs to be fixed eventually.

    text(1:length(b$n), b$stats[5,]+1, paste("p=", c(pvals,"")), srt=90, cex=0.8)
}


# boxplot function to plot certain string of data e.g. "pairing_score" or "dna_coverage"
# x is with tes y is without tes always for this setup with the names
bp <- function(x,y,string,main,leftname,rightname) {

    b<-boxplot(list(as.numeric(x[[string]]), as.numeric(y[[string]])),
    main = main,
    ylim = c(min(as.numeric(x[[string]]),as.numeric(y[[string]]),na.rm=T)*0.8, max(as.numeric(x[[string]]),as.numeric(y[[string]]),na.rm=T)*1.1),
    names = c(paste0(leftname,"\n(",nrow(x),")"), paste0(rightname,"\n(",nrow(y),")")),
    xlab = "4kb window regions",
    xaxt = 'n',
    ylab = paste(gsub("_", " ", string),"per 4kb window"))
    axis(side = 1, at = seq_along(b$names), labels = b$names, tick = FALSE)
    mtext(paste("P-value (Wilcox R.S.):", signif(wilcox.test(na.omit(as.numeric(x[[string]])), na.omit(as.numeric(y[[string]])), alternative = "two.sided")$p.value, digits=4)), side=1, line=5, cex=0.8)
}

# scatter plot function to show distribution with line of best fit
# x_outliers = number of outliers from x to remove from dataframe, e.g; 3 would omit 3 largest x value rows
sp <- function(x,y,main,xlab,ylab,outliers) {
    df <- data.frame(as.numeric(x),as.numeric(y))
    df <- na.omit(df)
    if (outliers > 0) {
        df <- df[!rowSums(df[1] >tail(sort(df[[1]]),outliers)[1]),]
    }
    plot(df[[1]], df[[2]], type = "p", main = main, xlab = xlab, ylab = ylab, cex.axis=0.8)
    lmod <- lm(df[[2]] ~ df[[1]])
    abline(lmod, col = 'red')
    mtext(paste("Linear Model adj. R²:", signif(summary(lmod)$adj.r.squared, digits = 4), "\nP. Value:", signif(summary(lmod)$coefficients[8], digits = 4)),side=1,line=5, cex = 0.8)
}


# reducing the model function
# runs the model, prompts the user if the most significant variable should be removed, reruns model, stops when user is satisfied
reducelm <- function(data){
    # initial model run
    fit <- lm(data)
    print(summary(fit))
    mostsigvar <- sort(summary(fit)$coefficients[,4])[ !names(sort(summary(fit)$coefficients[,4])) %in% "(Intercept)" ][1]
    # repeat prompt loop
    repeat{
        prompt <- readline(paste0("Reduce the multiple regression model by removing most significant variable (", gsub("`", "", names(mostsigvar)), "; P-value: ", signif(mostsigvar, digits=4), ") and rerun model? (y/N)"))
        if(regexpr(prompt, 'y', ignore.case = TRUE) == 1){
            data <- data[, !names(data) %in% gsub("`", "", names(mostsigvar))]
            fit <- lm(data)
            print(summary(fit))
            mostsigvar <- sort(summary(fit)$coefficients[,4])[ !names(sort(summary(fit)$coefficients[,4])) %in% "(Intercept)" ][1]
        } else {
            break
        }
    }
    return(fit)
}



make_het_te_summary <- function(data,names) {
    tmp <-data
    tmp[["het_te_family"]]<-replace(tmp[["het_te_family"]], which(tmp[["het_te_family"]] != "."), names[1])
    tmp[["het_mat_te_family"]]<-replace(tmp[["het_mat_te_family"]], which(tmp[["het_mat_te_family"]] != "."), names[2])
    tmp[["het_pat_te_family"]]<-replace(tmp[["het_pat_te_family"]], which(tmp[["het_pat_te_family"]] != "."), names[3])
    tmp[["hom_te_family"]]<-replace(tmp[["hom_te_family"]], which(tmp[["hom_te_family"]] != "."), names[4])
    tmp$te_summary<-"No TE"
    tmp$te_summary<-replace(tmp$te_summary, which(tmp[["het_te_family"]] != "."), tmp[["het_te_family"]])
    tmp$te_summary<-replace(tmp$te_summary, which(tmp[["het_mat_te_family"]] != "."), tmp[["het_mat_te_family"]])
    tmp$te_summary<-replace(tmp$te_summary, which(tmp[["het_pat_te_family"]] != "."), tmp[["het_pat_te_family"]])
    tmp$te_summary<-replace(tmp$te_summary, which(tmp[["hom_te_family"]] != "."), tmp[["hom_te_family"]])
    data$te_summary<-tmp$te_summary

#    tmp<-gsub("\\.", NA, tmp)
#    data$het_te_summary <- na.omit(gsub("\\.", NA, unlist(data.frame(tmp[["het_te_family"]], tmp[["het_mat_te_family"]], tmp[["het_pat_te_family"]], tmp[["hom_te_family"]])[-1])))
#    with(tmp,ifelse(,B,A))
#    pairwise.t.test(df2[[cola]], df2[[colb]], p.adjust.method=padj
    return(data)
}




